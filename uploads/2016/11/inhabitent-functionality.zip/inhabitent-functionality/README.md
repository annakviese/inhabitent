# Inhabitent Functionality Plugin

A template for a WordPress functionality plugin for Inhabitent website.
